/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.josemejia.system.config;

public class Enviroment {
    protected static final String USER
            ="root";
    protected static final String PASSWORD
            ="OSU/5535@kinal";
    protected static final String DATA_BASE 
            ="exoduscodex_in4av";
    protected static final String LOCATION_SERVICE
            ="127.0.0.1:3307";
}